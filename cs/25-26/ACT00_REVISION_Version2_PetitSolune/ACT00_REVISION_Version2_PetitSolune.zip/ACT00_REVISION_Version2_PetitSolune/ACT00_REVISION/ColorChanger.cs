﻿using System;
using System.Collections.Generic;
using System.Linq;
using System.Text;
using System.Threading.Tasks;

namespace _5T24_PetitSolune_enigma
{
    internal class ColorChanger
    {
        public void red()
        {
            Console.ForegroundColor = ConsoleColor.Red;
        }

        public void blue()
        {
            Console.ForegroundColor= ConsoleColor.Blue;
        }

        public void green()
        {
            Console.ForegroundColor= ConsoleColor.Green;
        }

        public void cyan()
        {
            Console.ForegroundColor=ConsoleColor.Cyan;
        }

        public void white()
        {
            Console.ForegroundColor= ConsoleColor.White;
        }

        public void black()
        {
            Console.ForegroundColor = ConsoleColor.Black;
        }

        public void yellow()
        {
            Console.ForegroundColor = ConsoleColor.Yellow;
        }

        public void darkblue()
        {
            Console.ForegroundColor = ConsoleColor.DarkBlue;
        }

        public void darkcyan()
        {
            Console.ForegroundColor = ConsoleColor.DarkCyan;
        }

        public void magenta()
        {
            Console.ForegroundColor = ConsoleColor.Magenta;
        }

        

    }
}
